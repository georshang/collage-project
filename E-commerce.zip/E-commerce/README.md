# E-commerce
This is the dynamic e-commerce website where customer can visit page, search products, register, purchase products and it also have admin panel where admin can add, delete & update -- post, site &amp; user.

# what languages are used?
I have used html, css, bootstrap, js, jquery, php and mysql
This is purely based on procedural php.

# Level
It is intermediate level of projects based on frontend as well as backend where i have used procedural php 

# what i learn?
This php e-commerce projects brings my passion back. Such a project will definetly improves you core-skills and probably boosts your performance and thinking capacity.
Another important things is that chosing php as first backend language will be easier and doing e-commerce projects on php will probably be easier and will surely built your self confidence in backend fields.
