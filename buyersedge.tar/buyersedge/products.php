<!DOCTYPE html>

<?php
include("include/connection.php");

$userID = $_COOKIE['userID'];

if(isset($userID))
{
    $getUser = "select * from users where user_id='$userID'";
    $runUser = mysqli_query($con, $getUser);
    $row = mysqli_fetch_array($runUser);
    $userName = $row['user_name'];
    $userImage = $row['user_image'];
}

//get products data
$getProduct = "select * from products LIMIT 8";
$runProduct = mysqli_query($con, $getProduct);
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iMart | Products</title>
    <link rel="stylesheet" href="styles/home.css">
    <link rel="stylesheet" href="styles/basic.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="wrapper">

        <?php 
			include 'header.php'; 
	    ?>

        <div class="exclusive-products">
            <div class=" container">
                <?php
                    while($rowProduct = mysqli_fetch_array($runProduct)){
                        $productImage = $rowProduct['product_image'];
                        $productName = $rowProduct['product_name'];
                        $productPrice = $rowProduct['product_price'];
                        $productID = $rowProduct['product_id'];

                        echo"
                            <div class='section' onclick=location.href='view-product.php?product_id=$productID'>
                                <img src='storage/products/$productImage' alt=''>
                                <h1>$productName</h1>
                                <h2>Rs $productPrice</h2>
                            </div>
                        ";
                    }
                ?>
            </div>
        </div>

        <?php 
			include 'footer.php'; 
	?>

    </div>
</body>

<script src="jquery/jquery-3.5.1.min.js"></script>
<script src="scripts/home.js"></script>

</html>