-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 17, 2023 at 12:29 AM
-- Server version: 10.6.8-MariaDB-1
-- PHP Version: 8.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imart`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `user_id` varchar(50) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `product_id` varchar(11) NOT NULL,
  `product_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`user_id`, `cart_id`, `product_id`, `product_name`) VALUES
('9WiGPj6t5eW8dPF', 23, '4', 'Apple iPhone 14 Pro');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` int(100) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(100) NOT NULL,
  `order_address` text NOT NULL,
  `order_name` varchar(255) NOT NULL,
  `order_phone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_id`, `user_id`, `product_id`, `order_date`, `order_status`, `order_address`, `order_name`, `order_phone`) VALUES
(4, 183251763, '9WiGPj6t5eW8dPF', 4, '2023-04-15', 'pending', 'Nagercoil', 'customer', '9876543210'),
(5, 249390521, 'XfYsUejNiSHcxhP', 7, '2023-04-16', 'pending', '', 'Henlin', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(255) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_des` text NOT NULL,
  `product_price` int(100) NOT NULL,
  `upload_date` date NOT NULL,
  `product_owner_id` varchar(100) NOT NULL,
  `product_category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_image`, `product_des`, `product_price`, `upload_date`, `product_owner_id`, `product_category`) VALUES
(4, 'Apple iPhone 14 Pro', '20230415151521-20230415120831.jpg', '48MP camera system (Ultra Wide, Wide, and Telephoto)\r\n 12MP TrueDepth camera\r\n128 GB', 115000, '2023-04-15', 'gn5LOHYplbSi2a7', 'mobile'),
(5, 'Asus Rog Flow X13', '20230415152234-20230415124112-rog.jpg', 'ASUS ROG Flow X13 Ryzen 7 Octa Core 5800HS - (16 GB/1 TB SSD/Windows 10 Home/4 GB Graphics/NVIDIA GeForce GTX 1650/120 Hz) GV301QH-K6463TS 2 in 1 Gaming Laptop  (13.4 inch, Off Black, 1.30 kg, With MS Office)', 115000, '2023-04-15', 'gn5LOHYplbSi2a7', 'laptop'),
(7, 'HP pendrive', '20230415183012-20200801072342-s-l1600.jpg', '16 GB Hp Pendrive', 800, '2023-04-16', 'XfYsUejNiSHcxhP', 'pendrive');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_phone` varchar(10) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_image` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_role` varchar(10) NOT NULL DEFAULT 'normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `user_email`, `user_phone`, `user_address`, `user_image`, `user_password`, `user_role`) VALUES
(6, 'gn5LOHYplbSi2a7', 'GEORSHAN G', 'georshan@buyersedge.com', '9876543210', 'ngl', '204801_742.jpg', 'password', 'admin'),
(7, '9WiGPj6t5eW8dPF', 'customer', 'customer@buyersedge.com', NULL, NULL, NULL, 'customer', 'normal'),
(8, 'XfYsUejNiSHcxhP', 'Henlin', 'henlin@buyersedge.com', NULL, NULL, NULL, 'henlin', 'seller');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`cart_id`) USING BTREE;

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
