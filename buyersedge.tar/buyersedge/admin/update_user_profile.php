<?php
    include("../include/connection.php");

$userID = $_COOKIE['userID'];
if(!isset($userID)){
    echo"<script>window.open('home.php', '_self')</script>";
}

$getusers = "select * from users where user_id='$userID'";
$runusers = mysqli_query($con, $getusers);
$rowUsers = mysqli_fetch_array($runusers);

$userName = $rowUsers['user_name'];
$userRole = $rowUsers['user_role'];
$userAddress = $rowUsers['user_address'];
$userEmail = $rowUsers['user_email'];
$userPh = $rowUsers['user_phone'];

if(isset($_POST['update_btn'])){
       
    //below sql will update user details inside sql table when update is clicked
    include "includes/config.php";
    $sql = "UPDATE users 
             SET  user_name = '{$_POST['userName']}' ,
                  user_email = '{$_POST['userEmail']}' ,
                  user_address= '{$_POST['address']}' ,
                  user_phone = '{$_POST['ph_number']}',
                  user_role = '{$_POST['role']}' 
             WHERE user_id='{$userID}' ";
    $runsql = mysqli_query($con, $sql);
    echo"<script>window.open('manage-users.php', '_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iMart | Update User</title>
    <link rel="stylesheet" href="../styles/login-signup.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <script src="../scripts/cookies-manage.js"></script>
</head>

<body>
    <div class="wrapper">
        <div class="main-box">
            <h1>Update The User </h1>
            <form method="post" class="form" action="">

                <input type="text" placeholder="username" name="userName" value="<?php echo $userName ?>" >
                <input type="email" placeholder="email" name="userEmail" value="<?php echo $userEmail ?>" >
                <input type="text" placeholder="Address" name="address" value="<?php echo $userAddress ?>" >
                <input type="number" placeholder="Phone Number" name="ph_number" value="<?php echo $userPh ?>" >
                <label for="sel">ROLE</label><select id="role_update" name="role">
                    <?php 
                        if($userRole =='admin')
                        { ?>
                            <option value="admin" selected>Admin</option>
                            <option value="normal">Seller</option>
                            <option value="normal">Normal</option>
                    <?php  } 
                        elseif($userRole =='seller')
                        { ?> 
                                <option value="admin">Admin</option>
                                <option value="seller" selected>Seller</option>
                                <option value="normal" selected>Normal</option>
                                <?php 
                            }
                        else
                        { ?> 
                                <option value="admin">Admin</option>
                                <option value="seller">Seller</option>
                                <option value="normal" selected>Normal</option>
                                <?php 
                            } ?></select>
                <button type="submit" name="update_btn">UPDATE</button>

            </form>
        </div>
    </div>
</body>

</html>