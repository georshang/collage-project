<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/sidebar1.css">

</head>
<div class="sidebar">
    <div class="tophead">
        <h1 onclick="location.href='../home.php'">Buyer's Edge</h1>
    </div>
    <div class=top>
        <nav>
            <ul>
                <li onclick="location.href='dashboard.php'">Dashboard</li>
                <li onclick="manageProducts()">Add Products</li>
                <ul>
                    <li onclick="manageProducts(1)">Products</li>
                </ul>
                <li onclick="viewUsers()">Manage Users</li>
                <ul>
                    <li onclick="viewUsers(1)">Admin users</li>
                    <li onclick="viewUsers(2)">Sellers</li>
                    <li onclick="viewUsers(3)">Customers</li>
                </ul>
                <li onclick="viewOtherOrders()">Manage Orders</li>
                <ul>
                    <li onclick="viewOtherOrders(1)">Other Orders</li>
                </ul>
            </ul>
        </nav>
    </div>
    <div class="bottom">
        <p onclick="userLogout()">LogOut</p>
    </div>
</div>
<script src="../scripts/profile.js"></script>