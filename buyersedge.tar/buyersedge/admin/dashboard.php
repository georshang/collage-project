<!DOCTYPE html>
<?php
include("../include/connection.php");
include("../php/admin_access.php");

//$userRole = $_COOKIE['userID']
if($userRole == 'admin')
    {
        $productCountQuery = "select * from products";
        $runproductCountQuery = mysqli_query($con,$productCountQuery);
        $productCount = mysqli_num_rows($runproductCountQuery);

        $usersCountQuery = "select * from users";
        $runusersCountQuery = mysqli_query($con,$usersCountQuery);
        $usersCount = mysqli_num_rows($runusersCountQuery);

        $getUserQuery = "select * from users Order by id desc limit 5";
        $rungetUser = mysqli_query($con, $getUserQuery);

        $ordersCountQuery = "select * from orders";
        $runOrdersCountQuery = mysqli_query($con,$ordersCountQuery);
        $ordersCount = mysqli_num_rows($runOrdersCountQuery);

        $getOrderQuery = "select * from orders Order by id desc limit 5";
        $rungetOrder = mysqli_query($con, $getOrderQuery);
    }
    else{
        $productCountQuery = "select * from products where product_owner_id='$userID'";
        $runproductCountQuery = mysqli_query($con,$productCountQuery);
        $productCount = mysqli_num_rows($runproductCountQuery);

        $usersCountQuery = "select * from users where user_role='$userRole'";
        $runusersCountQuery = mysqli_query($con,$usersCountQuery);
        $usersCount = mysqli_num_rows($runusersCountQuery);

        $usersNormalCountQuery = "select * from users where user_role='normal'";
        $runNormalusersCountQuery = mysqli_query($con,$usersNormalCountQuery);
        $normalusersCount = mysqli_num_rows($runNormalusersCountQuery);

        $usersAdminCountQuery = "select * from users where user_role='admin'";
        $runAdminusersCountQuery = mysqli_query($con,$usersAdminCountQuery);
        $adminusersCount = mysqli_num_rows($runAdminusersCountQuery);

        $getUserQuery = "select * from users where user_id='$userID' Order by id desc limit 5";
        $rungetUser = mysqli_query($con, $getUserQuery);

        $ordersCountQuery = "select * from orders where product_id =(select product_id from products where product_owner_id='n7xd0I3EgxonmZY');";
        $runOrdersCountQuery = mysqli_query($con,$ordersCountQuery);
        $ordersCount = mysqli_num_rows($runOrdersCountQuery);

        $getOrderQuery = "select * from orders Order by id desc limit 5";
        $rungetOrder = mysqli_query($con, $getOrderQuery);
    }
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../styles/basic.css">
    <link rel="stylesheet" href="../styles/admin-basic.css">
    <link rel="stylesheet" href="../styles/admin-dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
</head>

<body>
    <?php
        $msg =$_GET['msg'];
        if(isset($msg)){
            echo "<script>alert('$msg')</script>";
        }
        ?>            
    <div class="container">
        <?php include('sidebar.php') ?>
        <div class="work-place">
        <!-- <?php include('../header.php') ?> -->
            <div class="summary">
                <div class="products" onclick="location.href='manage-products.php'">
                    <img src="../images/products.png" alt="">
                    <?php echo" <h1>0$productCount Products</h1> "; ?>
                    <p>All products</p>
                </div>
                <div class="users" onclick="location.href='../php/admin_user_access.php'">
                    <img src="../images/products.png" alt="">
                    <?php echo" <h3>0$usersCount $userRole Users </h3> "; ?>
                    <?php echo" <h4>0$normalusersCount Normal Users </h4> "; ?>
                    <p>Registered users</p>
                </div>
                <div class="orders" onclick="location.href='manage-orders.php'">
                    <img src="../images/products.png" alt="">
                    <?php echo" <h1>0$ordersCount Orders </h1> "; ?>
                    <p>Pending orders</p>
                </div>
                <div class="admins">
                    <img src="../images/products.png" alt="">
                    <?php echo "<h1>$adminusersCount Admins</h1>" ;?>
                    <p>Admin panel</p>
                </div>
            </div>
<?php if($userRole == 'admin'){ ?>
            <div class="summary-two">
                <div class="users-two">
                    <h1> Latest Users </h1>
                    <div class="list">
                        <?php
                        while($rowUsers = mysqli_fetch_array($rungetUser))
                        {
                            $userName = $rowUsers['user_name'];
                            $userID = $rowUsers['user_id'];

                            echo"
                            <p> $userName</p>
                            <p class='right'> #$userID</p>
                            ";
                        }
                        ?>
                    </div>
                </div>
                <div class="orders-two">
                    <h1> Pending Orders </h1>
                    <div class="list">
                        <?php
                        while($rowOrders = mysqli_fetch_array($rungetOrder))
                        {
                            $orderID = $rowOrders['order_id'];
                            $orderDate = $rowOrders['order_date'];

                            echo"
                            <p>  $orderDate </p>
                            <p class='right'>  #$orderID </p>
                            ";
                        }
                        ?>
                    </div>
                </div>
            </div>
                  <?php  } ?>
        </div>
    </div>
    <script src="../scripts/admin.js"></script>
    <script src="../scripts/profile.js"></script>
</body>

</html>