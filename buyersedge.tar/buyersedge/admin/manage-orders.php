<!DOCTYPE html>
<?php
include("../include/connection.php");
include("../php/admin_access.php");

$data = $_GET['data'];

//getting products data
if($userRole == 'admin'){

    $getOrdersQuery = "select * from orders where product_id in (select product_id from products where product_owner_id='$userID');";
    $runOrdersQuery = mysqli_query($con,$getOrdersQuery);

    $getOtherOrdersQuery = "select * from orders where product_id not in (select product_id from products where product_owner_id='$userID');";
    $runOtherOrdersQuery = mysqli_query($con, $getOtherOrdersQuery);
}
else{
    $getOrdersQuery = "select * from orders where product_id in (select product_id from products where product_owner_id='$userID');";
    $runOrdersQuery = mysqli_query($con,$getOrdersQuery);
}


?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="../styles/admin-basic.css">
    <link rel="stylesheet" href="../styles/admin-manage-orders.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
</head>

<body>
<div class="container">
    <?php include('sidebar.php')?>
    <div class="orders-container">
            <?php 
            if ( $data == 0 ) 
            { 
                if($userRole == 'admin' || $userRole == 'seller')
                { ?>
                        <div>
                            <h1> Your Product Orders</h1>
                            <?php
                                while($rowOrder = mysqli_fetch_array($runOrdersQuery)) {
                                    $orderID = $rowOrder['order_id'];
                                    $productID = $rowOrder['product_id'];
                                    $orderDate = $rowOrder['order_date'];
                                    $orderStatus = $rowOrder['order_status'];
                                    $orderName = $rowOrder['order_name'];
                                    $orderAddress = $rowOrder['order_address'];

                                    echo"
                                    <div class='order'>
                                    <h2>#$orderID </h2>
                                        <div class='main'>
                                            <div class='order-details'>
                                                <p>Product ID: <span> $productID</span></p>
                                                <p>Order Date: <span>$orderDate</span></p>
                                                <p>Order Status: <span>$orderStatus</span></p>
                                            </div>
                                            <div class='order-user'>
                                                <p>Name: <span> $orderName</span></p>
                                                <p>Address: <span>$orderAddress</span></p>
                                            </div>
                                        </div>
                                        <div class='controller'>
                                            <button class='controller-btns' onClick='manageOrder(\"processing\",$orderID,$data)' >Accept</button>
                                            <button class='controller-btns' onClick='manageOrder(\"shipped\",$orderID,$data)'>Shipped</button>
                                            <button class='controller-btns' onClick='manageOrder(\"rejected\",$orderID,$data)'>Reject</button>
                                        </div>
                                    </div>
                                    ";
                                }
                            ?>
                        <div> <?php
                }
            } 
            elseif( $data == 1 )
            { 
                if($userRole == 'admin')
                { ?>
                    <div>
                                <h1> Other Product Orders</h1>
                                <?php
                                    while($rowOrder = mysqli_fetch_array($runOtherOrdersQuery)) {
                                        $orderID = $rowOrder['order_id'];
                                        $productID = $rowOrder['product_id'];
                                        $orderDate = $rowOrder['order_date'];
                                        $orderStatus = $rowOrder['order_status'];
                                        $orderName = $rowOrder['order_name'];
                                        $orderAddress = $rowOrder['order_address'];

                                        echo"
                                        <div class='order'>
                                        <h2>#$orderID </h2>
                                            <div class='main'>
                                                <div class='order-details'>
                                                    <p>Product ID: <span> $productID</span></p>
                                                    <p>Order Date: <span>$orderDate</span></p>
                                                    <p>Order Status: <span>$orderStatus</span></p>
                                                </div>
                                                <div class='order-user'>
                                                    <p>Name: <span> $orderName</span></p>
                                                    <p>Address: <span>$orderAddress</span></p>
                                                </div>
                                            </div>
                                            <div class='controller'>
                                                <button class='controller-btns' onClick='manageOrder(\"processing\",$orderID,$data)' >Accept</button>
                                                <button class='controller-btns' onClick='manageOrder(\"shipped\",$orderID,$data)'>Shipped</button>
                                                <button class='controller-btns' onClick='manageOrder(\"rejected\",$orderID,$data)'>Reject</button>
                                            </div>
                                        </div>
                                        ";
                                    }
                                ?>
                        </div> <?php 
                }
                else{
                    echo"<script>window.open('../admin/dashboard.php?msg=AccessDenied!', '_self')</script>";
                } 
            }?>
    </div>

</div>
    <script src="../jquery/jquery-3.5.1.min.js"></script>
    <script src="../scripts/admin.js"></script>
</body>

</html>