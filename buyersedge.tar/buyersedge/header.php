<!DOCTYPE html>

<?php
include("include/connection.php");

$userID = $_COOKIE['userID'];

?>
<html>
<head>
    <link rel="stylesheet" href="styles/header.css">
    <link rel="stylesheet" href="styles/basic.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
</head>
<body>
    <div class="header-container">
        <div class="header">
            <div class="left-side">
                <p onclick="location.href='home.php'">Buyer's Edge</p>
            </div>
            <div class="center-menu">
                <nav>
                    <ul>
                        <li><a href="home.php">HOME</a></li>
                        <li><a href="products.php">PROCUCTS</a></li>
                        <li><a href="cart.php">MY CART</a></li>
                        <li><a href="orders.php">ORDERS</a></li>
                        <li><a href="about.php">ABOUT US</a></li>
                    </ul>
                </nav>
            </div>
            <div class="right-side">
                <img id="cart" src="images/shopping-cart.png" onclick="cart()" alt="">
                    <?php
                        if(isset($userID))
                            {
                                $getUser = "select * from users where user_id='$userID'";
                                $runUser = mysqli_query($con, $getUser);
                                $row = mysqli_fetch_array($runUser);
                                $userName = $row['user_name'];
                                $userImage = $row['user_image'];

                                if(empty($userImage)){
                                    echo"<img id='dp' src='images/user.png' alt='' onclick='viewProfile()'>";
                                } else{
                                    echo"<img id='dp' src='storage/users/$userImage' alt=''style='border-radius: 50px;' onclick='viewProfile()'/>";
                                }
                            }
                            else {
                                echo"<img id='dp' src='images/user.png' alt='' onclick='viewProfile()'>";
                            }
                    ?>
            </div>
        </div>
    </div>
    <script src="scripts/header.js"></script>
</body>